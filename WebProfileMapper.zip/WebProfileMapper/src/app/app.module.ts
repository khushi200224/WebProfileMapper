import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module'; // Your routing module
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

// Components
import { AppComponent } from './app.component';
import { ProfileListComponent } from './components/profile-list/profile-list.component';
import { ProfileDetailsComponent } from './components/profile-details/profile-details.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { MapComponent } from './components/map/map.component';

// Services
import { ProfileService } from './services/profile.service';

// For Google Maps (if using Google Maps)
import { GoogleMapsModule } from '@angular/google-maps';

// For Mapbox (if using Mapbox)
// import { NgxMapboxGLModule } from 'ngx-mapbox-gl';

@NgModule({
  declarations: [
    AppComponent,            // Root component
    ProfileListComponent,     // Profile listing component
    ProfileDetailsComponent,  // Profile details component
    AdminDashboardComponent,  // Admin dashboard component
    MapComponent             // Map component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,        // For routing between components
    FormsModule,             // For forms in the admin dashboard and profile management
    HttpClientModule,        // For making HTTP requests (e.g., if fetching data from an API)
    
    // Google Maps (uncomment this if using Google Maps)
    GoogleMapsModule,  
    
    // Mapbox (uncomment this if using Mapbox)
    // NgxMapboxGLModule.withConfig({
    //   accessToken: 'your-mapbox-access-token' // Add your Mapbox access token here
    // })
  ],
  providers: [ProfileService], // Register ProfileService
  bootstrap: [AppComponent]    // Bootstrap with root AppComponent
})
export class AppModule { }
