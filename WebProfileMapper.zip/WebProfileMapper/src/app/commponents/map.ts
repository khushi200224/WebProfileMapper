import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css'],
})
export class MapComponent {
  @Input() lat!: number;
  @Input() lng!: number;

  get center() {
    return { lat: this.lat, lng: this.lng };
  }
}
