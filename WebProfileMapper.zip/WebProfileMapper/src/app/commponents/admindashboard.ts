import { Component } from '@angular/core';
import { ProfileService, Profile } from '../../services/profile.service';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css'],
})
export class AdminDashboardComponent {
  newProfile: Profile = { id: 0, name: '', photo: '', description: '', address: '', lat: 0, lng: 0 };
  profiles: Profile[] = [];

  constructor(private profileService: ProfileService) {}

  ngOnInit(): void {
    this.profiles = this.profileService.getProfiles();
  }

  onSubmit() {
    this.profileService.addProfile(this.newProfile);
    this.newProfile = { id: 0, name: '', photo: '', description: '', address: '', lat: 0, lng: 0 };
  }

  deleteProfile(id: number) {
    this.profileService.deleteProfile(id);
  }
}
