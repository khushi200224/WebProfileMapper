import { Component, OnInit } from '@angular/core';
import { ProfileService, Profile } from '../../services/profile.service';

@Component({
  selector: 'app-profile-list',
  templateUrl: './profile-list.component.html',
  styleUrls: ['./profile-list.component.css'],
})
export class ProfileListComponent implements OnInit {
  profiles: Profile[] = [];

  constructor(private profileService: ProfileService) {}

  ngOnInit(): void {
    this.profiles = this.profileService.getProfiles();
  }

  viewProfile(profile: Profile) {
    // Show the profile on the map (trigger map component)
  }

  viewDetails(profile: Profile) {
    // Navigate to profile details page
  }
}
