import { Injectable } from '@angular/core';

export interface Profile {
  id: number;
  name: string;
  photo: string;
  description: string;
  address: string;
  lat: number;
  lng: number;
}

@Injectable({
  providedIn: 'root',
})
export class ProfileService {
  private profiles: Profile[] = [
    {
      id: 1,
      name: 'John Doe',
      photo: 'assets/john.jpg',
      description: 'A software engineer from NYC.',
      address: 'New York, USA',
      lat: 40.7128,
      lng: -74.0060,
    },
    // Add more profiles here
  ];

  constructor() {}

  getProfiles() {
    return this.profiles;
  }

  addProfile(profile: Profile) {
    this.profiles.push(profile);
  }

  updateProfile(id: number, updatedProfile: Profile) {
    const index = this.profiles.findIndex((profile) => profile.id === id);
    if (index !== -1) {
      this.profiles[index] = updatedProfile;
    }
  }

  deleteProfile(id: number) {
    this.profiles = this.profiles.filter((profile) => profile.id !== id);
  }
}
